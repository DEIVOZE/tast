import json
import random

from flask import Flask, render_template

app = Flask(__name__)


@app.route('/member')
def member():
    with open("templates\member.json", encoding="utf-8") as f:
        data = json.load(f)
        a = random.choice(data)
        print(a)
    return render_template('persons.html', data=a, title=f"Участник {a['name']}")



if __name__ == '__main__':
    app.run(port=5000, host='127.0.0.1')
